Assingment10 v 1.0

Installation (Win 64 and Win 32):
1) download zip folder
2) extract zip folder
3) navigate to Assignment10Win64 > application.windows64
	   (or Assignment10Win32 > application.windows32
4) double click Assignment10.exe
5) ACE ENGG 202!!

Release History:

Version 1.0.0 (initial release)
April 4, 2020

Author:
thefeistyone

Contact:
thefeistyone on discord